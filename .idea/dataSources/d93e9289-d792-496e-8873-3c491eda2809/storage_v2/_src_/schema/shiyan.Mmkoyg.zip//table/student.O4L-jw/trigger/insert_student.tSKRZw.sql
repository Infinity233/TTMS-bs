create trigger insert_student
  after INSERT
  on student
  for each row
  update stu_num set num = num+1;

